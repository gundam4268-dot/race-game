import os
import asyncio

def resource_path(relative_path):
    """ C:\ """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
import pygame
import sys
import math
from time import time

# ==========================================
# 1. 初始化 Pygame 與視窗
# ==========================================
pygame.init()
pygame.mixer.init()

screen = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("本機 Python 賽車遊戲 - 120幀極速流暢版")
clock = pygame.time.Clock()

# ==========================================
# 2. 載入圖片物件與設定
# ==========================================
def load_img(name):
    try:
        return pygame.image.load(resource_path(name)).convert_alpha()
    except:
        img = pygame.Surface((100, 100))
        img.fill((200, 200, 200))
        return img

# 同時存在 a.png（地圖）與 1.png（邊界圖）
img_road = load_img('a.png') 
img_border = load_img('1.png') 

img_check1 = load_img('check.png')
img_check2 = load_img('check.png')
img_car = load_img('car.png')
img_dashboard = load_img('dashboard.png')
img_result_board = load_img('result.png')

# 賽車初始運動設定
car_dir = 0.0     # 車子角度
speed = 0.0       # 車速

# 所有物件相對於世界地圖的初始中心點位置
road_x, road_y = 600, 400
border_x, border_y = 600, 400
check1_x, check1_y = 600, 400
check2_x, check2_y = 600, -1750

# 🌟【效能優化關鍵】把圖片遮罩轉換移到迴圈外面！
# 讓電腦在遊戲啟動時只做一次轉換，這樣每秒跑 120 幀也不會卡頓
mask_car = pygame.mask.from_surface(img_car)
mask_border = pygame.mask.from_surface(img_border)

# ==========================================
# 3. 遊戲全域變數
# ==========================================
start_time = time()
turns = 1
timer = 0.0
t1, t2, t3, t4 = 0.0, 0.0, 0.0, 0.0
is_checked = False
result_board_hidden = True

try:
    font = pygame.font.SysFont("microsoftjhenghei", 40)
except:
    font = pygame.font.Font(None, 40)

def draw_text(text, x, y, color_str, size):
    color = (255, 255, 255) if color_str == 'white' else (0, 0, 0)
    text_surface = font.render(str(text), True, color)
    screen.blit(text_surface, (x, y))

# ==========================================
# 4. 遊戲主迴圈
# ==========================================
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 結算畫面鎖定
    if turns == 4:
        screen.fill((0, 0, 0))
        if not result_board_hidden:
            rect_rb = img_result_board.get_rect(center=(600, 400))
            screen.blit(img_result_board, rect_rb)
            
        draw_text(round(t1, 3), 560, 320, 'white', 40)
        draw_text(round(t2, 3), 560, 395, 'white', 40)
        draw_text(round(t3, 3), 560, 470, 'white', 40)
        draw_text(round(t4, 3), 560, 545, 'white', 40)
        
        pygame.display.flip()
        clock.tick(120)
        continue

    # --- 鍵盤控制偵測 ---
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:     # 按左鍵：向左轉
        car_dir -= 1.5
        if speed < 0:
            speed = 0
        else:
            speed -= 2
    if keys[pygame.K_RIGHT]:    # 按右鍵：向右轉
        car_dir += 1.5
        if speed < 0:
            speed = 0
        else:
            speed -= 2

    # --- 移動物理計算 ---
    rad = math.radians(car_dir)
    # 因為您把遊戲從 60幀 改成了 120幀，移動速度在同一個 speed 下會變兩倍快
    # 這裡微調除以 20，維持跟原本一樣好控制的移動感
    move_x = (speed / 20) * math.cos(rad)
    move_y = (speed / 20) * math.sin(rad)

    # 地圖底圖、邊界圖、與所有檢查點進行完美的相對同步位移
    road_x -= move_x
    road_y -= move_y
    border_x -= move_x
    border_y -= move_y
    check1_x -= move_x
    check1_y -= move_y
    check2_x -= move_x
    check2_y -= move_y

    # --- 最高速限制與自動加速（確保在馬路上時可以衝到 332） ---
    if speed > 144:
        speed = 144
    else:
        speed += 1

    # 建立所有物件的外框矩形位置
    rect_road = img_road.get_rect(center=(int(road_x), int(road_y)))
    rect_border = img_border.get_rect(center=(int(border_x), int(border_y)))
    rect_car = img_car.get_rect(center=(600, 400))
    rect_check1 = img_check1.get_rect(center=(int(check1_x), int(check1_y)))
    rect_check2 = img_check2.get_rect(center=(int(check2_x), int(check2_y)))

    # --- 🎯【效能最佳化】圖片透明度精準偵測法 ---
    # 計算車子與 1.png 之間的相對偏移量
    offset_x = rect_border.left - rect_car.left
    offset_y = rect_border.top - rect_car.top
    
    # 這裡主迴圈內只做 overlap 比對，不再重新抓取 mask，速度會極快！
    if mask_car.overlap(mask_border, (offset_x, offset_y)):
        if speed < 45:
            speed = 45
        else:
            speed -= 20 # 碰到邊界時的限制速度
    else:
        pass # 沒有壓到 1.png 的地方，在馬路上極速前進！

    # --- 賽道檢查點碰撞判定邏輯 ---
    if rect_car.colliderect(rect_check1) and is_checked:
        if turns == 1: t1 = timer
        elif turns == 2: t2 = timer
        elif turns == 3: t3 = timer
            
        start_time = time()
        turns += 1
        is_checked = False
        if turns == 4:
            t4 = (t1 + t2 + t3) / 3
            result_board_hidden = False

    if rect_car.colliderect(rect_check2):
        is_checked = True

    # 刷新計時器數值
    timer = time() - start_time

    # --- 5. 繪製畫面 (圖層完美疊加，無小地圖) ---
    screen.fill((117, 182, 110))         # 1. 最底層：草地綠色
    
    screen.blit(img_road, rect_road)     # 2. 第二層：賽道底圖 a.png
    screen.blit(img_border, rect_border) # 3. 第三層：道路邊界圖 1.png
    screen.blit(img_check1, rect_check1) # 4. 第四層：檢查點 1
    screen.blit(img_check2, rect_check2) # 5. 第五層：檢查點 2
    
    # 6. 第六層：玩家的賽車
    rotated_car = pygame.transform.rotate(img_car, -car_dir)
    rect_rot_car = rotated_car.get_rect(center=(600, 400))
    screen.blit(rotated_car, rect_rot_car)
    
    # 7. 第七層：覆蓋上層儀表板 UI 外框
    screen.blit(img_dashboard, (0, 0))
    
    # 8. 最上層：填入儀表板的即時文字數據
    draw_text(f"{int(speed)} km/h", 55, 70, 'white', 40)
    draw_text(f"{turns}/3", 310, 70, 'black', 40)
    draw_text(f"{round(timer, 3)}s", 1000, 70, 'white', 40)

    pygame.display.flip()
    clock.tick(120) # 完美支援 120 幀高刷

pygame.quit()
sys.exit()
